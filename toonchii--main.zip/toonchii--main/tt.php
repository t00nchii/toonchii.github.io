
                                  <?php if($row['vtuNetAirtimeId'] == 1){ ?> 

                <?php }else{ ?>

                <?php }?>